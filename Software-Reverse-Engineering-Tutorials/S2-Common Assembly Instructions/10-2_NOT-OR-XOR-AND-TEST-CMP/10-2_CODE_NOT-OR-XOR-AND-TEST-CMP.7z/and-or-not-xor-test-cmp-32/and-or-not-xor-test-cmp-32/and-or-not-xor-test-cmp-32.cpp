#include <iostream>


void asmfunc() {

	unsigned char abyte = 0x02;
	unsigned short aword = 0x0202;
	unsigned int adword = 0x02020202;

	char anbyte = -0x5;
	char bnbyte = 0x5;

	int a = 5;
	int b;

	__asm {


		; -------------------------------- - NOT
		mov al, 10b
		not al
		not al

		mov eax, 02020202h
		not ax
		not eax

		not [abyte]
		not [aword]
		not [adword]

		; --------------------------------------------OR

		mov al, 5h
		mov[abyte], 5h
		or al, 2h
		or [abyte], 2h

		mov al, 5h
		mov bl, 2h
		or al, bl

		mov[abyte], 5h
		or [abyte], bl

		mov al, 5h
		mov[abyte], 2h
		or al, [abyte]

		mov[abyte], 41h
		or [abyte], 20h

		or al, bl
		or ax, bx
		or eax, ebx
		or ax, 11h
		or eax, 11h
		or [aword], 11h
		or al, 1111h
		or [abyte], 1111h
		; or al, ax
		; or ax, al
		; or eax, al
		; or eax, [abyte]


		; --------------------------------------------XOR

		mov al, 7h
		mov[abyte], 7h
		xor al, 2h
		xor [abyte], 2h

		mov al, 7h
		mov bl, 2h
		xor al, bl

		mov[abyte], 7h
		xor [abyte], bl

		mov al, 7h
		mov[abyte], 2h
		xor al, [abyte]


		xor al, bl
		xor ax, bx
		xor eax, ebx
		xor ax, 11h
		xor eax, 11h
		xor [aword], 11h
		xor al, 1111h
		xor [abyte], 1111h
		;xor al, ax
		; xor ax, al
		; xor eax, al
		; xor eax, [abyte]

		; --------------------------------------------AND

		mov al, 5h
		mov[abyte], 5h
		and al, 6h
		and [abyte], 6h

		mov al, 5h
		mov bl, 6h
		and al, bl

		mov[abyte], 5h
		and [abyte], bl

		mov al, 5h
		mov[abyte], 6h
		and al, [abyte]

		mov[abyte], 61h
		and [abyte], 0dfh

		and al, bl
		and ax, bx
		and eax, ebx
		and ax, 11h
		and eax, 11h
		and [aword], 11h
		and al, 1111h
		and [abyte], 1111h
		; and al, ax
		; and ax, al
		; and eax, al
		; and eax, [abyte]

		; -------------------------------------------- - TEST

		;--------------------------------ZF-ZR
		mov al, 5h
		mov bl, 2h
		test al, bl

		; --------------------------------PF - PE
		mov al, 7h
		mov bl, 3h
		test al, bl

		; --------------------------------SF - PL
		mov al, 0FDh
		mov bl, 0FFh
		test al, bl

		; --------------------------------------------------CMP

		mov al,5h
		mov ah,2h
		mov bl,5h

		cmp al,ah			;al>ah ZF=0 SF=0
		cmp ah,al			;ah<ah ZF=0 SF=1
		cmp al,bl			;al=ah ZF=1 SF=0

		
		mov [adword],11111111h
		mov [abyte],10h

		cmp al,2h
		cmp [abyte],10h
		cmp al,[abyte]
		cmp [abyte],al
		cmp [adword],2h
		cmp [abyte],2222h
		cmp al,2222h
		;cmp al,[adword]
		;cmp [adword],al

	}
}


int main()
{
	asmfunc();
}

