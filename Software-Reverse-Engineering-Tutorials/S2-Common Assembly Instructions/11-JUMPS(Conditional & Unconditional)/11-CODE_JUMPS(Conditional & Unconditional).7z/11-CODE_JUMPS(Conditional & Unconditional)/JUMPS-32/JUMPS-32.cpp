#include <iostream>

char abyte;
int adword;


void asmfunc() {


	__asm {


		; --------------------------------jmp


		jmp onhexgroup
		mov al, 13h

		onhexgroup :
			mov al, 5h

		jmp near ptr onhex

		onhex :
			mov bl, 13h
					
		mov al, 12h
		jmp short $ + 4
		jmp short $ + 8
		mov al, 13h
		jmp short $ - 4
		mov al, 14h
		mov al, 15h

		mov adword, esi
		;jmp adword

		;----------------------- jz
		
		mov al,5h
		test al,2
		jz lbljz
		mov al,bl
		mov cx,ax

		lbljz:
			mov al,20h
			cmp al,10h
			jnz lbljnz
			mov al, bl
			mov cx, ax

		lbljnz:
			mov al,12h
			cmp al,5h
			jg lbljg
			mov al, bl
			mov cx, ax

		lbljg:
			mov al,1h


			
		ret
	}
}



int main()
{
			asmfunc();
			printf("Onhexgroup.ir");
}

