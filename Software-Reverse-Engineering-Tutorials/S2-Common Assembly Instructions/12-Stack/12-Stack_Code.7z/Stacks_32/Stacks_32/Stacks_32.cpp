#include <iostream>


void asmfunc() {

	unsigned char abyte = 0x11;
	unsigned short aword = 0x1111;
	unsigned int adword = 0x11111111;

	__asm {

		; ------------------------------------Push


		mov abyte, 14h

		push 13h
		push 1212h
		push 11121314h
		push al
		push ax
		push eax
		push abyte
		push aword
		push adword
		

		


		; ------------------------------------POP
		pop al
		pop ax
		pop eax
		pop abyte
		pop aword
		pop adword


		; -------------------------------------- - ADD & SUB

		push 61616161h
		sub esp, 8h
		push 41414141h
		add esp, 8h
		push 42424242h

		;-----------------------------------mov lea

		mov eax,esp
		mov esp,ebx

		lea eax,[esp]
		lea esp,[eax]

		; ------------------------------------EBP


		push ebp
		pop ebp
		sub ebp, 8h
		add ebp, 8h
		mov ebp, esp
		mov esp, ebp
		lea eax, [ebp]
		lea ebp, [ecx]

		ret

	}

}

int main()
{
	asmfunc();
}

