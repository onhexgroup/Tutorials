#include <iostream>

int __cdecl addfunc_cd(int a, int b, int c, int d) {
	int r = a + b + c + d;
	return r;
}


int __stdcall addfunc_std(int a, int b, int c, int d) {
	int r = a + b + c + d;
	return r;
}


int __fastcall addfunc_fast(int a, int b, int c, int d) {
	int r = a+b + c + d;
	return r;
}

short addfunc(char a, short b, int c, int d) {
	short r = b + 0x11;
	return r;
}


int main()
{
	int r;
	short short_r;

	r = addfunc_cd(1,2,3,4);
	printf("Result from cdecl= %d\n", r);

	r = addfunc_std(1, 2, 3, 4);
	printf("Resultfrom stdcall= %d\n", r);

	r = addfunc_fast(1, 2, 3, 4);
	printf("Result from fastcall= %d\n", r);

	short_r = addfunc(0x11, 0x2222, 0x33333333, 0x44444444);


}
