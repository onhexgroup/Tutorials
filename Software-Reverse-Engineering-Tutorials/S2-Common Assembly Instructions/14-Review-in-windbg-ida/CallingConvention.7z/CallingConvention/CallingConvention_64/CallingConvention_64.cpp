#include <iostream>


int addfunc(int a, int b, int c, int d,int e) {
	int r = a + b + c + d + e;
	return r;
}

long long addfunc2(char a, short b, int c, long long d, char a1, short b2, int c3, long long c4) {

	return 0x1111111111111111;
}


int main()
{
	int r;
	long long r3;

	r = addfunc(1, 2, 3, 4, 5);
	printf("Result= %d\n", r);

	r3 = addfunc2(0x11, 0x2222, 0x33333333, 0x4444444444444444, 0x11, 0x2222, 0x33333333, 0x4444444444444444);
}