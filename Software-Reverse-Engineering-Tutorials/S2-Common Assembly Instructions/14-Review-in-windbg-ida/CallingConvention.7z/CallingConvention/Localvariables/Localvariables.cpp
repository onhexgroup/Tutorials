#include <iostream>

int add(int a, int b, int c, int d, int e) {
	int r = 0;
	int r1 = 1;
	int r2 = 2;
	r = a + b + c + d + e + r1 + r2;
	return r;

}



int main()
{
	int r = 0;
	r = add(1,2,3,4,5);
	printf("Result is: %d",r);
}

