#include <iostream>

extern "C" void asmfunc();


int main()
{
	asmfunc();
}