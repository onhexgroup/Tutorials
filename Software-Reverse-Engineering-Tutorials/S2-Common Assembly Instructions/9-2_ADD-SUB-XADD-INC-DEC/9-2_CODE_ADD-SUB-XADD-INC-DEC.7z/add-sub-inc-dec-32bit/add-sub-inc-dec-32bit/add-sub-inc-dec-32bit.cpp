#include <iostream>


void asmfunc() {

	unsigned char abyte = 0x11;
	unsigned char bbyte = 0x12;

	unsigned short aword = 0x1111;
	unsigned short bword = 0x1212;

	unsigned int adword = 0x11111111;
	unsigned int bdword = 0x12121212;

	char anbyte = -0x5;
	char bnbyte = 0x5;
	
	int a = 5;
	int b;

	__asm {

		;------------------------------------ADD

		mov al, 22h
		add al, 11h				;r8 = r8 + imm8

		mov[abyte], 22h
		add[abyte], 11h			;m8 = m8 + imm8


		mov ax, [aword]
		mov bx, [bword]
		add ax, bx				;r16 = r16 + r16

		mov[adword], 11111111h
		mov ebx, [bdword]
		add ebx, [adword]		;r32 = r32 + m32

		mov ebx, 11111111h
		add[bdword], ebx		;m32 = m32 + r32


		mov al, [abyte]
		mov bl, [bbyte]
		add al, bl				; byte = byte + byte

		mov ax, [aword]
		mov bx, [bword]
		add ax, bx				; word = word + word

		mov eax, [adword]
		mov ebx, [bdword]
		add eax, ebx			; dword = dword + dword


		mov bx, [bword]
		add bx, 11h				;r16=r16+imm8
		add eax, 1111h			;r32=r32+imm16
		add bl, 11111111h		;r8=r8+imm32
		;add bl, eax			;r8=r8+r32
		;add eax, bl			;r32=r32+r8
		;add ebx, [bword]		;r32=r32+m16




		; ------------------------------------sub

		mov al, 22h
		sub al, 11h				; r8 = r8 - imm8

		mov[abyte], 22h
		sub[abyte], 11h			; m8 = m8 - imm8


		mov ax, [aword]
		mov bx, [bword]
		sub ax, bx				; r16 = r16 - r16

		mov[adword], 11111111h
		mov ebx, [bdword]
		sub ebx, [adword]		; r32 = r32 - m32

		mov ebx, 11111111h
		sub [bdword], ebx		; m32 = m32 - r32


		mov al, [abyte]
		mov bl, [bbyte]
		sub al, bl				; byte = byte - byte

		mov ax, [aword]
		mov bx, [bword]
		sub ax, bx				; word = word - word

		mov eax, [adword]
		mov ebx, [bdword]
		sub eax, ebx			; dword = dword - dword


		mov bx, [bword]
		sub bx, 11h				; r16 = r16 - imm8
		sub eax, 1111h			; r32 = r32 - imm16
		sub bl, 11111111h		; r8 = r8 - imm32
		;sub bl, eax			; r8 = r8 - r32
		;sub eax, bl			; r32 = r32 - r8
		;sub ebx, [bword]		; r32 = r32 - m16
		
		;-------------------------------------------------------- neg

		mov al,anbyte
		mov bl,bnbyte

		mov eax, [a]
		neg eax
		mov b, eax

		; ---------------------------------------------- - flags

		; ---------------------- - zero flag
		mov al, 2h
		mov bl, 2h
		sub al, bl


		; ------------------------over flow
		mov al, 7fh
		mov bl, 1h
		add al, bl

		; ------------------------Parity Flag
		mov al, 2h
		mov bl, 1h
		add al, bl

		; ------------------------Auxiliary Carry Flag
		mov al, 10h
		sub al, 1h


		; ------------------------Carry Flag
		mov al, 0ffh
		add al, 1h


		; ------------------------sign flag
		mov al, 2h
		sub al, 3h


		;----------------------------------------------------- xadd


		mov eax, 11121314h
		mov ebx, 21222324h
		
		xadd al, bl			;bl=al - al=al+bl
		xadd ax,bx			; bx = ax - ax = ax + bx
		xadd eax,ebx		; eax = ebx - eax = eax + ebx

		mov al, 14h
		xadd[abyte], al		; abyte = al - abyte = abyte + al
		xadd[aword], ax		; aword = ax - aword = aword + ax
		xadd[adword], eax	; adword = eax - adword = adword + eax



		;---------------------------------------------------------------------- inc

		mov eax,11223344h

		inc al					;al=al+1
		inc ax					;ax=ax+1
		inc eax					;eax=eax+1

		inc [abyte]				;abyte=abyte+1
		inc [aword]				;aword=aword+1
		inc [adword]			;adword=adword+1


		;---------------------------------------------------------------------- DEC

		mov eax,11223344h

		dec al					;al=al-1
		dec ax					;ax=ax-1
		dec eax					;eax=eax-1

		dec [abyte]				;abyte=abyte-1
		dec [aword]				;aword=aword-1
		dec [adword]			;adword=adword-1






	}

	printf("Negative of %d is %d\n", a, b);
	
}

int main()
{

	asmfunc();

	return 0;
}


