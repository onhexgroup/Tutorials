// asmtest.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

extern "C" void asmfunc();


int main()
{
	asmfunc();
}

