#include <iostream>


unsigned char glbvar = 0x85;      //global var

void asmtest() {

	unsigned char myvar = 0x41;
	short arr[4] = {0x1111,0x2222,0x3333,0x4444};


	__asm {

		; -------------------------------------- - imm->r

		mov al, 11h					; imm8 to r8
		mov ax, 2222h				; imm16 to r16
		mov eax, 33333333h			; imm32 to r32
		mov eax, 55h				; imm8 to r32


		; ------------------------------------------r->r

		mov ah, al					; r8 to r8
		mov bx, ax					; r16 to r16
		mov eax, ebx				; r32 to r32

		; -------------------------------------------- - imm->m

		mov[edi], 24h					; imm8 to m
		mov[myvar], 42h					; imm8 to m
		mov[myvar + 1], 11h				; imm8 to m + 1
		mov[myvar + 2 * 3], 12h			; imm8 to m[base + index * scale]
		mov[myvar + 2 * 3 + 2], 13h		; imm8 to m

		mov[arr + 2 * 2], 11h			; imm8 to index 2

		mov ebx, 2h
		mov[arr + ebx * 2], 13h			; imm8 to index 2


		; ----------------------------------------------m->r
		mov bl, [myvar]				; m to r8
		mov bl, [myvar + 1]
		mov bl, [myvar + 2 * 2]


		; ----------------------------------------------r->m

		mov[myvar], bl				; r8 to m
		mov[myvar + 1], ch			; r8 to m + 1
		mov[myvar + 2 * 3], bl		; r8 to m


		; ---------------------------------------------- - tips
		; MOV ax, bl					;invalid
		; MOV ax, [myvar]				; invalid
		 MOV ax, word ptr[myvar]
		 MOV eax, 11h
		 MOV ax, [ebx]


		; ----------------------------------------------lea

		lea ecx, [eax]

		lea eax, [myvar]		; m->r32
		lea bx, [myvar]			; m->r16

		lea eax, [arr]
		lea eax, [arr + 2 * 2]

		lea eax, [arr + 2 * 2]
		mov eax, 4321h


		; ----------------------------------------------tips
		lea eax, [myvar]
		mov eax, 12345678h

		
		lea eax, [glbvar]
		mov eax,OFFSET [glbvar]
			


		ret

	}

}

int main()
{
	asmtest();
}

