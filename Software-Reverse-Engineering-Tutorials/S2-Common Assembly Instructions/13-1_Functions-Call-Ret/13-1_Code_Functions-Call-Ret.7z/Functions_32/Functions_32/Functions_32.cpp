#include <iostream>



void func1() {
	__asm {
		mov al,15
	}
	return ;
}


void asmfunc() {


	__asm {

		mov al,12h
		call func1
		mov al, 12h

	}

}


int main()
{
	asmfunc();
}

