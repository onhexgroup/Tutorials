#include <iostream>


void asmfunc() {

	unsigned char abyte = 0x11;
	unsigned char bbyte = 0x12;

	unsigned short aword = 0x1111;
	unsigned short bword = 0x1212;

	unsigned int adword = 0x11111111;
	unsigned int bdword = 0x12121212;

	char anbyte = -0x5;
	char bnbyte = 0x5;
	
	int a = 5;
	int b;

	__asm {

		;------------------------------------ADD

		mov al, 22h
		add al, 11h				;r8 = r8 + imm8

		mov[abyte], 22h
		add[abyte], 11h			;m8 = m8 + imm8


		mov ax, [aword]
		mov bx, [bword]
		add ax, bx				;r16 = r16 + r16

		mov[adword], 11111111h
		mov ebx, [bdword]
		add ebx, [adword]		;r32 = r32 + m32

		mov ebx, 11111111h
		add[bdword], ebx		;m32 = m32 + r32


		mov al, [abyte]
		mov bl, [bbyte]
		add al, bl				; byte = byte + byte

		mov ax, [aword]
		mov bx, [bword]
		add ax, bx				; word = word + word

		mov eax, [adword]
		mov ebx, [bdword]
		add eax, ebx			; dword = dword + dword


		mov bx, [bword]
		add bx, 11h				;r16=r16+imm8
		add eax, 1111h			;r32=r32+imm16
		add bl, 11111111h		;r8=r8+imm32
		;add bl, eax			;r8=r8+r32
		;add eax, bl			;r32=r32+r8
		;add ebx, [bword]		;r32=r32+m16




		; ------------------------------------sub

		mov al, 22h
		sub al, 11h				; r8 = r8 - imm8

		mov[abyte], 22h
		sub[abyte], 11h			; m8 = m8 - imm8


		mov ax, [aword]
		mov bx, [bword]
		sub ax, bx				; r16 = r16 - r16

		mov[adword], 11111111h
		mov ebx, [bdword]
		sub ebx, [adword]		; r32 = r32 - m32

		mov ebx, 11111111h
		sub [bdword], ebx		; m32 = m32 - r32


		mov al, [abyte]
		mov bl, [bbyte]
		sub al, bl				; byte = byte - byte

		mov ax, [aword]
		mov bx, [bword]
		sub ax, bx				; word = word - word

		mov eax, [adword]
		mov ebx, [bdword]
		sub eax, ebx			; dword = dword - dword


		mov bx, [bword]
		sub bx, 11h				; r16 = r16 - imm8
		sub eax, 1111h			; r32 = r32 - imm16
		sub bl, 11111111h		; r8 = r8 - imm32
		;sub bl, eax			; r8 = r8 - r32
		;sub eax, bl			; r32 = r32 - r8
		;sub ebx, [bword]		; r32 = r32 - m16
		
		;-------------------------------------------------------- neg

		mov al,anbyte
		mov bl,bnbyte

		mov eax, [a]
		neg eax
		mov b, eax

	}

	printf("Negative of %d is %d\n", a, b);
	
}

int main()
{

	asmfunc();

	return 0;
}


